import tkinter as tk
root = tk.Tk()
root.title('Blue')
root.geometry('200x80')
w1 = tk.Label(root, text="莫忘少年凌云志",bg='pink')
w2=tk.Label(root,text="曾许天下第一流",bg='yellow')
w1.pack(side='left')
w2.pack(side='left')
root.mainloop()

# import tkinter as tk
# root = tk.Tk()
# root.title('Blue')
# root.geometry('200x80')
# w1 = tk.Label(root, text="莫忘少年凌云志",bg='pink')
# w2=tk.Label(root,text="曾许天下第一流",bg='yellow')
# w1.pack(pady=3)
# w2.pack(pady=1)
# root.mainloop()