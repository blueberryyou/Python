from tkinter import*
win=Tk()
img=PhotoImage(file='D:\Desktop\###.png')
Label(win,image=img).pack()
win.mainloop()